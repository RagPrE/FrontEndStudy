# 04 Protocol

Be sure to check out these modules:

- https://godoc.org/github.com/libp2p/go-libp2p
- https://godoc.org/github.com/libp2p/go-libp2p-core/host#Host
